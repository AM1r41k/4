﻿using Models.Abstract;

namespace Models
{
    public class Visitor : Entity
    {
        public string Name { get; set; }
    }
}
