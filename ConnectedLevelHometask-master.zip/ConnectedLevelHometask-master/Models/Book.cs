﻿using Models.Abstract;

namespace Models
{
    public class Book : Entity
    {
        public string Name { get; set; }
    }
}
