﻿using Models.Abstract;

namespace Models
{
    public class Author : Entity
    {
        public string FullName { get; set; }
    }
}
